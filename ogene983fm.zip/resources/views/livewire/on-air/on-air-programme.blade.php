  <div class="text-right col-lg-3 col-md-3" wire:poll.10m>
      <ul class="nav-right">
          <img id="onAir" src="{{ $onAir->coverImage ?? null }}" alt="" class="img-fluid">
      </ul>
  </div>
