<?php return array (
  'on-air.on-air-programme' => 'App\\Http\\Livewire\\OnAir\\OnAirProgramme',
);