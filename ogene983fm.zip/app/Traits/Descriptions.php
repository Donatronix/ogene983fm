<?php

namespace App\Traits;

use App\Models\Description\Description;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

/**
 * Trait DescribeAble
 * @package App\Traits
 */
trait Descriptions
{
    public function saveAbout($description)
    {
        return  $this->saveDescription($description);
    }

    public function updateAbout($description)
    {
        return  $this->updateDescription($description);
    }

    public function deleteAbout()
    {
        return  $this->deleteDescription();
    }

    public function saveExcerpt($description)
    {
        return  $this->saveDescription($description);
    }

    public function updateExcerpt($description)
    {
        return  $this->updateDescription($description);
    }

    public function deleteExcerpt()
    {
        return  $this->deleteDescription();
    }

    public function saveSummary($description)
    {
        return  $this->saveDescription($description);
    }

    public function updateSummary($description)
    {
        return  $this->updateDescription($description);
    }

    public function deleteSummary()
    {
        return  $this->deleteDescription();
    }

    public function saveDescription($description)
    {
        $describe = new Description;
        $describe->body = $description;
        return  $this->description()->save($describe);
    }

    public function updateDescription($description)
    {
        $descriptionId = $this->description->id;
        $describe = Description::find($descriptionId);
        $describe->body = $description;
        return $describe->save();
    }

    public function deleteDescription()
    {
        $descriptionId = $this->description->id;
        $describe = Description::find($descriptionId);
        return $describe->delete();
    }


    public function description()
    {
        return $this->morphOne('App\Models\Description\Description', 'described');
    }

    public function getAboutAttribute()
    {
        return $this->description->body ?? null;
    }

    public function getExcerptAttribute()
    {
        return $this->description->body ?? null;
    }

    public function getSummaryAttribute()
    {
        return $this->description->body ?? null;
    }
}