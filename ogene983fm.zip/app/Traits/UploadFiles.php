<?php

namespace App\Traits;

use App\Helpers\Helper;
use App\Models\Image\Image;
use App\Traits\UploadAble;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;


/**
 * Trait UploadImage
 * @package App\Traits
 */
trait UploadFiles
{
    use UploadAble;


    /**
     * @param UploadedFile $file
     * @param null $folder
     * @param string $disk
     * @param null $filename
     * @return false|string
     */
    public function upload(UploadedFile $files, $folder = null, $filename = null)
    {
        DB::beginTransaction();
        try {
            foreach ($files as $file) {
                $image = new Image;
                $image->image = $this->uploadFile($file, $folder, $filename);
                $this->uploads()->save($image);
            }
        } catch (\Throwable $th) {
            DB::rollback();
            throw $th;
        }
        DB::commit();
        return true;
    }

    /**
     * Update image in model
     *
     * @param \App\Models\Image\Image $uploadId
     * @param UploadedFile $file
     * @param null $folder
     * @param string $disk
     * @param null $filename
     * @return boolean
     */
    public function updateUpload(Image $uploadId, UploadedFile $file, $folder = null, $filename = null)
    {
        DB::beginTransaction();
        try {
            $helper = new Helper;
            $uploadId = $uploadId->id;
            $image = Image::findOrFail($uploadId);
            $imageFile = $image->image;
            if ($folder == null) {
                $folder = $helper->getFileDirectoryName($imageFile);
            }
            $image->image = $this->uploadFile($file, \str_replace(asset(""), "", $folder), $filename);
            $image->save();
            $this->deleteFile($imageFile);
        } catch (\Throwable $th) {
            DB::rollback();
            throw $th;
            return false;
        }
        DB::commit();
        return true;
    }

    /**
     * Delete model images
     *
     * @param \App\Models\Image\Image $uploadId
     * @return boolean
     */
    public function deleteUpload(Image $uploadId)
    {
        DB::beginTransaction();
        try {
            $uploadId = $uploadId->id;
            $imgFile = Image::findOrFail($uploadId);
            $this->deleteFile($imgFile->image);
            $imgFile->delete();
        } catch (\Throwable $th) {
            DB::rollback();
            return false;
        }
        DB::commit();
        return true;
    }

    /**
     * Uploads
     *
     * @return void
     */
    public function uploads()
    {
        return $this->morphMany('App\Models\Image\Image', 'imageable');
    }
}
