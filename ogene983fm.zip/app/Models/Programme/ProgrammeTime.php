<?php

namespace App\Models\Programme;

use carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

/**
 * App\Models\Programme\ProgrammeTime
 *
 * @property-read mixed $from
 * @property-read mixed $to
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Programme\Programme[] $programmes
 * @property-read int|null $programmes_count
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\ProgrammeTime newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\ProgrammeTime newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\ProgrammeTime onAir()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\ProgrammeTime query()
 * @mixin \Eloquent
 * @property int $id
 * @property string $day
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\ProgrammeTime whereDay($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\ProgrammeTime whereFrom($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\ProgrammeTime whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\ProgrammeTime whereTo($value)
 */
class ProgrammeTime extends Model
{
    public $timestamps = false;
    protected $fillable = ['day', 'from', 'to'];

    public function programmes()
    {
        return $this->belongsToMany('App\Models\Programme\Programme');
    }

    public function getFromAttribute($value)
    {
        return date('h:ia', $value);
    }

    public function getToAttribute($value)
    {
        return date('h:ia', $value);
    }

    public function scopeOnAir($query)
    {
                $currentTime = \intval(strtotime(Carbon::now()->toTimeString()));
        return     $query->where('day', Carbon::now()->englishDayOfWeek)
            ->where('from', '<=', $currentTime)
            ->where('to', '>', $currentTime);
    }
}
