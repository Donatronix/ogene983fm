<?php

namespace App\Models\Programme;

use App\Traits\Descriptions;
use App\Traits\Taggable;
use App\Traits\UploadImage;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Auth;
use Spatie\Searchable\Searchable;
use Spatie\Searchable\SearchResult;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;

/**
 * App\Models\Programme\Programme
 *
 * @property-read \App\Models\Description\Description|null $description
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Discussion\Discussion[] $discussions
 * @property-read int|null $discussions_count
 * @property-read mixed $about
 * @property-read mixed $content
 * @property-read mixed $cover_image
 * @property-read mixed $excerpt
 * @property-read mixed $summary
 * @property-read \App\Models\Image\Image|null $image
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Presenter\Presenter[] $presenters
 * @property-read int|null $presenters_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Programme\ProgrammeDay[] $programmeDays
 * @property-read int|null $programme_days_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Programme\ProgrammeTime[] $programmeTimes
 * @property-read int|null $programme_times_count
 * @property-read \Illuminate\Database\Eloquent\Collection|\App\Models\Tag\Tag[] $tags
 * @property-read int|null $tags_count
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme myProgrammes()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme newModelQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme newQuery()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme onAir()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme query()
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme userProgrammes(\App\Models\User $user)
 * @mixin \Eloquent
 * @property int $id
 * @property string $title
 * @property string $slug
 * @property \Illuminate\Support\Carbon|null $created_at
 * @property \Illuminate\Support\Carbon|null $updated_at
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme whereCreatedAt($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme whereId($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme whereSlug($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme whereTitle($value)
 * @method static \Illuminate\Database\Eloquent\Builder|\App\Models\Programme\Programme whereUpdatedAt($value)
 */
class Programme extends Model implements Searchable
{
    use Descriptions;
    use HasSlug;
    use Taggable;
    use UploadImage;

    protected $fillable = ['title'];

    /**
     * Get the options for generating the slug.
     */
    public function getSlugOptions(): SlugOptions
    {
        return SlugOptions::create()
            ->generateSlugsFrom('title')
            ->saveSlugsTo('slug')
            ->slugsShouldBeNoLongerThan(255);
    }

    /**
     * Get the route key for the model.
     *
     * @return string
     */
    public function getRouteKeyName()
    {
        return 'slug';
    }

    public function getSearchResult(): SearchResult
    {
        $url = route('programme.show', $this->slug);
        return new \Spatie\Searchable\SearchResult(
            $this,
            $this->id,
            $url
        );
    }

    public function presenters()
    {
        return $this->belongsToMany('App\Models\Presenter\Presenter');
    }

    public function discussions()
    {
        return $this->hasMany('App\Models\Discussion\Discussion', 'programme_id');
    }

    public function programmeTimes()
    {
        return $this->belongsToMany('App\Models\Programme\ProgrammeTime');
    }

    public function programmeDays()
    {
        return $this->belongsToMany('App\Models\Programme\ProgrammeDay');
    }


    /**
     * Get the model of the current programme on air
     *
     * @param [type] $query
     * @return void
     */
    public function scopeOnAir($query)
    {

        return $query
            ->whereHas('programmeTimes', function ($query) {
                $currentTime = \intval(strtotime(Carbon::now()->toTimeString()));
                $query->where('programme_times.from', '<=', $currentTime)
                    ->where('programme_times.to', '>', $currentTime)
                    ->where('programme_times.day', Carbon::now()->englishDayOfWeek);
            });
    }

    public function scopeMyProgrammes($query)
    {
        return $query->whereHas('users', function ($query) {
            $query->where('users.id', Auth::user()->id);
        });
    }

    private $user;

    public function scopeUserProgrammes($query, User $user)
    {
        $this->user = $user;
        return $query->whereHas('users', function ($query) {
            $query->where('users.id', $this->user->id);
        });
    }

    public function getContentAttribute()
    {
        return $this->about;
    }
}
