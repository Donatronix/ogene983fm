<?php

namespace App\Http\Livewire\OnAir;

use App\Models\Programme\ProgrammeTime;
use Carbon\Carbon;
use Livewire\Component;

class OnAirProgramme extends Component
{
    public $onAir;

    /**
     * Render html of component
     *
     * @return void
     */
    public function render()
    {
        $currentTime = strtotime(date('h:i a'));
        $programmeTime = ProgrammeTime::where('day', Carbon::now()->englishDayOfWeek)
            ->where('from', '<', $currentTime)
            ->where('to', '>', $currentTime)
            ->orderBy('id', 'desc')->first();
        $this->onAir = $programmeTime ? $programmeTime->programmes->first() : null;
        return view('livewire.on-air.on-air-programme', ['onAir' => $this->onAir]);
    }
}
