<?php

namespace App\Http\Controllers\Discussion;

use App\Helpers\Helper;
use App\Http\Controllers\Controller;
use App\Models\Discussion\Discussion;
use App\Models\Programme\Programme;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DiscussionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function dashboard()
    {
        $discussions = Discussion::orderBy('created_at', 'desc')->get();
        return view('site.dashboard.discussions.index', ['discussions' => $discussions]);
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $discussions = Discussion::with(['programme', 'presenter'])->get();
        $routes = [];
        foreach ($discussions as $discussion) {
            $routes[] = route('discussion.show', ['discussion' => $discussion->slug, 'programme' => $discussion->programme->slug]);
        }
        return view('site.pages.blog', ['blogs' => $discussions, 'routes' => $routes, 'title' => 'Discussions']);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $programmes = Programme::pluck('title', 'id');
        return view('site.dashboard.discussions.create', ['programmes' => $programmes]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->flash();
        $this->validate($request, [
            'title'     => ['required', 'string', 'unique:discussions,title'],
            'programme' => ['required', 'numeric', 'exists:programmes,id'],
            'summary'   => ['required', 'string'],
        ]);
        DB::beginTransaction();
        try {
            $discussion = new Discussion;
            $discussion->title = $request->title;
            $discussion->programme_id = $request->programme;
            $discussion->save();
            $discussion->saveSummary($request->summary);
            $helper = new Helper;
            $tags = $helper->getKeywords(join(" ", [$request->title, $request->summary]));
            $discussion->attachTags($tags);
        } catch (\Throwable $th) {
            DB::rollback();
            throw $th;
        }
        DB::commit();
        alert()->success('Discussion created successfully');
        return redirect()->route('discussion.dashboard');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Discussion\Discussion $discussion
     * @return \Illuminate\Http\Response
     */
    public function show(Discussion $discussion)
    {
        $helper = new Helper;
        $categoryName = $helper->uppercaseWords($discussion->programme->title);
        $title = $categoryName . "-" . $helper->uppercaseWords($discussion->title);
        $breadcrumb['category'] = $categoryName;
        $breadcrumb['title'] = $helper->uppercaseWords($discussion->title);
        $breadcrumb['route'] = route('discussion.programme', ['programme' => $discussion->programme->slug]);
        return view('site.pages.blog-details', ['blog' =>  $discussion, 'presenter' =>  $discussion->programme->presenter->name, 'programme' =>  $discussion->programme, 'title' =>  $title]);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Discussion\Discussion $discussion
     * @return \Illuminate\Http\Response
     */
    public function programme(Programme $programme)
    {
        $helper = new Helper;
        $title = $helper->uppercaseWords($programme->title) . " - Discussions";
        return view('site.pages.blog', ['blogs' =>  $programme->discussions, 'presenter' =>  $programme->presenter->name, 'programme' =>  $programme->title, 'title' =>  $title]);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Discussion\Discussion $discussion
     * @return \Illuminate\Http\Response
     */
    public function edit(Discussion $discussion)
    {
        $programmes = Programme::pluck('title', 'id');
        return view('site.dashboard.discussions.edit', ['discussion' => $discussion, 'programmes' => $programmes]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Discussion\Discussion $discussion
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Discussion $discussion)
    {
        $request->flash();
        $this->validate($request, [
            'title'     => ['required', 'string', 'unique:discussions,title'],
            'programme' => ['required', 'numeric', 'exists:programmes,id'],
            'summary'   => ['required', 'string'],
        ]);
        DB::beginTransaction();
        try {
            $discussion->title = $request->title;
            $discussion->programme_id = $request->programme;
            $discussion->save();
            $discussion->updateSummary($request->summary);
            $helper = new Helper;
            $tags = $helper->getKeywords(join(" ", [$request->title, $request->summary]));
            $discussion->syncTags($tags);
        } catch (\Throwable $th) {
            DB::rollback();
            throw $th;
        }
        DB::commit();
        alert()->success('Discussion updated successfully');
        return redirect()->route('discussion.dashboard');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Discussion\Discussion $discussion
     * @return \Illuminate\Http\Response
     */
    public function destroy(Discussion $discussion)
    {
        DB::beginTransaction();
        try {
            $discussion->deleteSummary();
            $discussion->delete();
        } catch (\Throwable $th) {
            DB::rollback();
            throw $th;
        }
        DB::commit();
        alert()->success('Discussion deleted successfully');
        return redirect()->route('discussion.dashboard');
    }
}
