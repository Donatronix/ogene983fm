<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

use App\Http\Controllers\Contact\ContactController;
use App\Http\Controllers\Discussion\DiscussionController;
use App\Http\Controllers\Gallery\AlbumController;
use App\Http\Controllers\Gallery\AlbumUploadController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Post\PostController;
use App\Http\Controllers\Presenter\PresenterController;
use App\Http\Controllers\Programme\ProgrammeController;
use App\Http\Controllers\Programme\ProgrammeTimeController;
use App\Http\Controllers\SongOfTheWeek\SongOfTheWeekController;
use App\Http\Controllers\Tag\TagController;
use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Str;

Auth::routes();

Route::get('/', [HomeController::class, 'index'])->name('home');
Route::group(['prefix' => 'dashboard', 'middleware' => ['auth', 'admin']], function () {
    Route::get('/', [HomeController::class, 'dashboard'])->name('dashboard');
});
Route::get('/home', [HomeController::class, 'index']);
Route::get('/about', [HomeController::class, 'about'])->name('about');
Route::get('/contact', [HomeController::class, 'contact'])->name('contact');



Route::group(['prefix' => 'dashboard', 'middleware' => ['auth', 'admin']], function () {
    Route::group(['prefix' => 'discussion'], function () {
        Route::get('/', [DiscussionController::class, 'dashboard'])->name('discussion.dashboard');
        Route::get('/create', [DiscussionController::class, 'create'])->name('discussion.create');
        Route::post('/store', [DiscussionController::class, 'store'])->name('discussion.store');
        Route::get('/{discussion}/edit', [DiscussionController::class, 'edit'])->name('discussion.edit');
        Route::put('/{discussion}/update', [DiscussionController::class, 'update'])->name('discussion.update');
        Route::delete('/{discussion}/delete', [DiscussionController::class, 'destroy'])->name('discussion.delete');
    });
});
Route::group(['prefix' => 'discussion'], function () {
    Route::get('/', [DiscussionController::class, 'index'])->name('discussion.index');
    Route::get('/{programme}', [DiscussionController::class, 'programme'])->name('discussion.programme');
    Route::get('/{programme}/{discussion}', [DiscussionController::class, 'show'])->name('discussion.show');
});

Route::group(['prefix' => 'dashboard', 'middleware' => ['auth', 'admin']], function () {
    Route::group(['prefix' => 'programmes'], function () {
        Route::get('/', [ProgrammeController::class, 'dashboard'])->name('programme.dashboard');
        Route::get('/create', [ProgrammeController::class, 'create'])->name('programme.create');
        Route::post('/store', [ProgrammeController::class, 'store'])->name('programme.store');
        Route::get('/{programme}/edit', [ProgrammeController::class, 'edit'])->name('programme.edit');
        Route::put('/{programme}/update', [ProgrammeController::class, 'update'])->name('programme.update');
        Route::delete('/{programme}/delete', [ProgrammeController::class, 'destroy'])->name('programme.delete');
        Route::get('/schedule/{programme}/create', [ProgrammeTimeController::class, 'create'])->name('programme.time.create');
        Route::post('/schedule/{programme}/store', [ProgrammeTimeController::class, 'store'])->name('programme.time.store');
        Route::get('/schedule/{programme}/{programmeTime}/edit', [ProgrammeTimeController::class, 'edit'])->name('programme.time.edit');
        Route::put('/schedule/{programme}/{programmeTime}/update', [ProgrammeTimeController::class, 'update'])->name('programme.time.update');
        Route::delete('/schedule/{programme}/{programmeTime}/delete', [ProgrammeTimeController::class, 'destroy'])->name('programme.time.delete');
    });
});
Route::group(['prefix' => 'programmes'], function () {
    Route::get('/', [ProgrammeController::class, 'index'])->name('programme.index');
    Route::get('/{programme}', [ProgrammeController::class, 'show'])->name('programme.show');
});

Route::group(['prefix' => 'dashboard', 'middleware' => ['auth', 'admin']], function () {
    Route::group(['prefix' => 'on-air-personalities'], function () {
        Route::get('/', [PresenterController::class, 'dashboard'])->name('presenter.dashboard');
        Route::get('/create', [PresenterController::class, 'create'])->name('presenter.create');
        Route::post('/store', [PresenterController::class, 'store'])->name('presenter.store');
        Route::get('/{presenter}/edit', [PresenterController::class, 'edit'])->name('presenter.edit');
        Route::put('/{presenter}/update', [PresenterController::class, 'update'])->name('presenter.update');
        Route::delete('/{presenter}/delete', [PresenterController::class, 'destroy'])->name('presenter.delete');
    });
});
Route::group(['prefix' => 'on-air-personalities'], function () {
    Route::get('/', [PresenterController::class, 'index'])->name('presenter.index');
    Route::get('/{presenter}', [PresenterController::class, 'show'])->name('presenter.show');
});


//include routes for categories
require 'categoriesRoute.php';

Route::group(['prefix' => 'dashboard', 'middleware' => ['auth', 'admin']], function () {
    Route::group(['prefix' => 'gallery'], function () {
        Route::get('/', [AlbumController::class, 'dashboard'])->name('gallery.album.dashboard');
        Route::get('/album/create', [AlbumController::class, 'create'])->name('gallery.album.create');
        Route::post('/album/store', [AlbumController::class, 'store'])->name('gallery.album.store');
        Route::get('/album/{album}/edit', [AlbumController::class, 'edit'])->name('gallery.album.edit');
        Route::put('/album/{album}/update', [AlbumController::class, 'update'])->name('gallery.album.update');
        Route::delete('/album/{album}/delete', [AlbumController::class, 'destroy'])->name('gallery.album.delete');
        Route::get('/album/{album}', [AlbumController::class, 'showAlbum'])->name('gallery.album.showAlbum');

        Route::get('/{album}', [AlbumUploadController::class, 'dashboard'])->name('gallery.album.upload.dashboard');
        Route::get('/album/{album}/uploads/create', [AlbumUploadController::class, 'create'])->name('gallery.album.upload.create');
        Route::post('/album/{album}/uploads/store', [AlbumUploadController::class, 'store'])->name('gallery.album.upload.store');
        Route::get('/album/{album}/uploads/{albumUpload}/edit', [AlbumUploadController::class, 'edit'])->name('gallery.album.upload.edit');
        Route::put('/album/{album}/uploads/{albumUpload}/update', [AlbumUploadController::class, 'update'])->name('gallery.album.upload.update');
        Route::delete('/album/uploads/{albumUpload}/delete', [AlbumUploadController::class, 'destroy'])->name('gallery.album.upload.delete');
    });
});
Route::group(['prefix' => 'gallery'], function () {
    Route::get('/', [AlbumController::class, 'index'])->name('gallery.album.index');
    Route::get('/album/{album}', [AlbumController::class, 'show'])->name('gallery.album.show');
    Route::get('/album/{album}/{albumUpload}', [AlbumUploadController::class, 'show'])->name('gallery.album.upload.show');
});


Route::group(['prefix' => 'dashboard', 'middleware' => ['auth', 'admin']], function () {
    Route::group(['prefix' => 'blog'], function () {
        Route::get('/', [PostController::class, 'dashboard'])->name('post.dashboard');
        Route::get('/create', [PostController::class, 'create'])->name('post.create');
        Route::post('/store', [PostController::class, 'store'])->name('post.store');
        Route::get('/{post}/edit', [PostController::class, 'edit'])->name('post.edit');
        Route::put('/{post}/update', [PostController::class, 'update'])->name('post.update');
        Route::delete('/{post}/delete', [PostController::class, 'destroy'])->name('post.delete');
    });
});
Route::group(['prefix' => 'blog'], function () {
    Route::get('/', [PostController::class, 'index'])->name('post.index');
    Route::get('/{category}', [PostController::class, 'category'])->name('post.category');
    Route::get('/{category}/{post}', [PostController::class, 'show'])->name('post.show');
});

Route::group(['prefix' => 'dashboard', 'middleware' => ['auth', 'admin']], function () {
    Route::group(['prefix' => 'song-of-the-week'], function () {
        Route::get('/', [SongOfTheWeekController::class, 'dashboard'])->name('songoftheweek.dashboard');
        Route::get('/create', [SongOfTheWeekController::class, 'create'])->name('songoftheweek.create');
        Route::post('/store', [SongOfTheWeekController::class, 'store'])->name('songoftheweek.store');
        Route::get('/{songOfTheWeek}/edit', [SongOfTheWeekController::class, 'edit'])->name('songoftheweek.edit');
        Route::put('/{songOfTheWeek}/update', [SongOfTheWeekController::class, 'update'])->name('songoftheweek.update');
        Route::delete('/{songOfTheWeek}/delete', [SongOfTheWeekController::class, 'destroy'])->name('songoftheweek.delete');
    });
});
Route::group(['prefix' => 'song-of-the-week'], function () {
    Route::get('/{songOfTheWeek}', [SongOfTheWeekController::class, 'show'])->name('songoftheweek.show');
});



// Route::get('/tags/{tag}', TagController::class, 'show')->name('tag.show');
Route::get('/search', [SearchController::class, 'show'])->name('search');
Route::get('/onAir', [ProgrammeController::class, 'onAir'])->name('onAir');

Route::group(['prefix' => 'dashboard', 'middleware' => ['auth', 'admin']], function () {
    Route::group(['prefix' => 'contacts'], function () {
        Route::get('/', [ContactController::class, 'index'])->name('contact.dashboard');
        Route::get('/{contact}', [ContactController::class, 'show'])->name('contact.show');
        Route::post('/{contact}', [ContactController::class, 'get'])->name('contact.get');
        Route::delete('/{contact}/delete', [ContactController::class, 'destroy'])->name('contact.delete');
        Route::post('/send', [ContactController::class, 'send'])->name('contact.send');
        Route::post('/{contact}/reply', [ContactController::class, 'reply'])->name('contact.reply');
    });
});
Route::group(['prefix' => 'contacts'], function () {
    Route::post('/store', [ContactController::class, 'store'])->name('contact.store');
});

Route::get('send-mail', function () {
    return Str::random(40);
});



require 'newsletterRoutes.php';
require 'usersRoutes.php';




Route::get('/clear-cache', function () {
    Artisan::call('view:clear');
    Artisan::call('route:clear');
    Artisan::call('config:clear');
    Artisan::call('cache:clear');
    Artisan::call('config:cache');
    if (function_exists('exec')) {
        exec('rm ' . storage_path('logs/*'));
    }
    return redirect()->route('home');
});
